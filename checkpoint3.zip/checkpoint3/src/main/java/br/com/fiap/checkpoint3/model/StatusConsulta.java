package br.com.fiap.checkpoint3.model;

public enum StatusConsulta {
    AGENDADA,
    REALIZADA,
    CANCELADA
}
