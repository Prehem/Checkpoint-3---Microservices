package br.com.fiap.checkpoint3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Checkpoint3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
